Overview :
Creating an android app (apk) using flutter and google firebase (baas)
Problem:
A lot of fitness and body tone apps are overwhelming, complex, and difficult to follow. So we felt a need for an app that is easy to follow and gives results.

Solution and approach:
Approach:
Considering the global pandemic, the exercises were designed to be done at home with progressive overload. These exercises are bodyweight and calisthenics, which will be done in repetitions and circuits.Progressive overload will be done over the span of 30 days, and there will be rest days in between for every 4 days .

Key functionalities:
-Guided daily exercise session
-Bmi calculator
-mindful meditation 
-User authentication

